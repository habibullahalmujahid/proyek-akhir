<?php
 
namespace App\Http\Controllers;
 
use Illuminate\Http\Request;
 
class CobaController extends Controller
{
    public function index()
    {
        return "Selamat Routing Anda Sudah Benar";
    }
}